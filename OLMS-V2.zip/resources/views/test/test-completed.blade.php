
<div class="row">
  <div class="col-12">
      <div class="card" >
          <div class="card-body" id="test-content">
            <div class="px-3">
              <div class="row">
                <div class="col-12 text-center">
                  <h4 class="text-success">Your test has been completed successfully. <a href="{{ url('test/result?test_id='.$test_id) }}">Click here to view result</a></h4>
                </div>
              </div>
            </div>
          </div>
      </div>
  </div>
</div>
